
package net.mcreator.asiandifficulty.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.asiandifficulty.procedures.FluEffectRunProcedure;

public class FluEffectMobEffect extends MobEffect {
	public FluEffectMobEffect() {
		super(MobEffectCategory.HARMFUL, -13369549);
	}

	@Override
	public String getDescriptionId() {
		return "effect.asian_difficulty.flu_effect";
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		FluEffectRunProcedure.execute(entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
